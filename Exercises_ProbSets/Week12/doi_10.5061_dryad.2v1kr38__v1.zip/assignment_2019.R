#======================================
# Assignment analysis using assignPOP
#
# European lobster (Homarus gammarus)
# 
# Tom Jenkins | t.l.jenkins@exeter.ac.uk
#
# Jenkins et al. 2019 Evolutionary Applications
# 
#======================================

rm(list=ls(all=TRUE))
gc()

## Load packages
lib = c("ggplot2","RColorBrewer","assignPOP","adegenet","stringr")
lapply(lib, library, character.only=TRUE)


# ----------------- #
#
# Atlantic vs Mediterranean assignment tests
#
# ----------------- #

## Import data
lobster = read.Genepop("Genotype_data/lobster_basin_baseline.gen",
                       haploid=FALSE,
                       pop.names=c("Atlantic","Mediterranean"))
summary(lobster)
lobster

## Perform Monte-Carlo cross-validation
?assign.MC
assign.MC(lobster, 
          train.inds = c(0.5,0.7,0.9), # no. random ind from each pop
          train.loci = c(0.1,0.25,0.5,1), # top % high Fst loci (1=all loci)
          iterations = 100, # no. resampling times for each combination of training individuals and loci
          model = "svm", # predictive model used
          dir = "Basin_svm/") # directory

## Calculate assignment accuracies of MC cross-validation results
?accuracy.MC
accurMC = accuracy.MC(dir = "Basin_svm/")

## Identify informative loci
# check.loci(dir = "Basin_svm/", top.loci=20) # top 20 loci

## Plot assignment accuracy results
basin = accuracy.plot(accurMC, pop=c("Atlantic","Mediterranean"))+
          # labs(tag = "A")+
          ylab("Proportion of lobsters correctly assigned")+
          xlab("Proportion of individuals used in training dataset")+
          scale_y_continuous(limits=c(0,1))+
          theme(
            # facet labels
            strip.text = element_text(colour="black", size=15) 
          )
basin
# ggsave("Basin_assignment_accuracy.pdf")
# ggsave("Basin_assignment_accuracy.png")

## Print mean and SD across assignment tests
assign.matrix(dir="Basin_svm/",
              train.inds=0.7,
              train.loci=1)

## Perform assignment test on random set of unknown individuals
unknown = read.Genepop("Genotype_data/lobster_unknown.gen")
assign.X(lobster, unknown, dir="Basin_unknown_svm/",
         model="svm", mplot=TRUE)

## SVM model prediction results
df.svm = read.table("Basin_unknown_svm/AssignmentResult.txt", header=TRUE)
summary(df.svm$pred.pop)
subset(df.svm, pred.pop=="Mediterranean")
# write.csv(df.svm, file="TableS3.csv")

# Incorrect assignments
# Ios02
# Mul05
# Tor51



# ----------------- #
#
# Sampling location assignment
#
# ----------------- #

rm(list=ls(all=TRUE))
gc()

## Load packages
lib = c("ggplot2","RColorBrewer","assignPOP","adegenet","stringr")
lapply(lib, library, character.only=TRUE)

## Import Genind file
load("../lobster_1278ind_79snps_40pop.RData")
data_filt
summary(data_filt$pop)

## Combine Lazio and temporal samples
popNames(data_filt) = gsub("Idr16", "Idr", popNames(data_filt))
popNames(data_filt) = gsub("Idr17", "Idr", popNames(data_filt))
summary(data_filt$pop)

## Subset only Atlantic samples
atl.pops = c("Brd","Cor","Cro","Eye","Heb","Hel","Hoo","Idr","Iom","Ios",
             "Jer","Kil","Loo","Lyn","Mul","Oos","Ork","Pad","Pem",
             "Sbs","She","Sul","Ven","Vig","Flo","Gul","Sin","Lys","Kav","Ber","Tro")
data.atl = data_filt[pop=atl.pops]
data.atl
summary(data.atl$pop)

## Write Genepop file
# source("Create_random_datasets/TJ_genind2genepop_function.R")
# genind2genepop(data.atl, file="lobster_Atlantic_location.gen")

## Import data
sampling.loc = read.Genepop("Genotype_data/lobster_Atlantic_location.gen",
                            pop.names = popNames(data.atl))
summary(sampling.loc)

## Perform Monte-Carlo cross-validation
?assign.MC
assign.MC(sampling.loc, 
          train.inds = c(0.5,0.7,0.9), # no. random ind from each pop
          train.loci = c(0.25,0.5,1), # top % high Fst loci (1=all loci)
          iterations = 100, # no. resampling times for each combination of training individuals and loci
          model = "svm", # predictive model used
          dir = "Location_svm/") # directory

## Calculate assignment accuracies of MC cross-validation results
?accuracy.MC
accurMC = accuracy.MC(dir = "Location_svm/")

## Plot assignment accuracy results
loc = accuracy.plot(accurMC, pop=c("all","Vig","Oos","Ber"))+
  ylab("Proportion of lobsters correctly assigned")+
  xlab("Proportion of individuals used in training dataset")+
  scale_y_continuous(limits=c(0,1))+
  theme(
    # facet labels
    strip.text = element_text(colour="black", size=15) 
  )
loc
# ggsave("Location_assignment_accuracy.pdf", height=6, width=10)
# ggsave("Location_assignment_accuracy.png", height=6, width=10, dpi=600)

## Print mean and SD across assignment tests
assign.matrix(dir="Location_svm/",
              train.inds = 0.7,
              train.loci = 1)
  
### Atlantic location of origin assignment highly inaccurate


### Subset only Med samples
medpops = c("Laz","Tar","Sar13","Sar17","Ale","Tor","The","Sky")
med = data_filt[pop=medpops]
summary(med$pop)

## Write Genepop file
# source("Create_random_datasets/TJ_genind2genepop_function.R")
# genind2genepop(med, file="lobster_Med_location.gen")

## Import data
sampling.loc = read.Genepop("Genotype_data/lobster_Med_location.gen",
                            pop.names=c("Sar","Laz","Ale","The","Tor","Sky"))
summary(sampling.loc)

## Perform Monte-Carlo cross-validation
?assign.MC
assign.MC(sampling.loc, 
          train.inds = c(0.5,0.7,0.9), # no. random ind from each pop
          train.loci = c(0.25,0.5,1), # top % high Fst loci (1=all loci)
          iterations = 100, # no. resampling times for each combination of training individuals and loci
          model = "svm", # predictive model used
          dir = "Location_svm_Med/") # directory

## Calculate assignment accuracies of MC cross-validation results
?accuracy.MC
accurMC = accuracy.MC(dir = "Location_svm_Med/")

## Plot assignment accuracy results
loc_med = accuracy.plot(accurMC, pop=c("all","Sar","Laz","Ale","The","Tor","Sky"))+
  ylab("Proportion of lobsters correctly assigned")+
  xlab("Proportion of individuals used in training dataset")+
  scale_y_continuous(limits=c(0,1))+
  theme(
    # facet labels
    strip.text = element_text(colour="black", size=15) 
  )
loc_med
# ggsave("Location_assignment_accuracy_med.pdf", height=6, width=10)
# ggsave("Location_assignment_accuracy_med.png", height=6, width=10, dpi=600)

## Print mean and SD across assignment tests
assign.matrix(dir="Location_svm_Med/",
              train.inds = 0.7,
              train.loci = 1)

## Combine ggplots
library(cowplot)
plot_grid(loc, loc_med, nrow=2, labels = c("A","B"))
# ggsave(file="assignment_location.png", width=10, height=9)
# ggsave(file="assignment_location.pdf", width=10, height=9)



# ----------------- #
#
# Regional Atlantic assignment
#
# Atlantic vs North Sea vs Scandinavia
#
# ----------------- #

rm(list=ls(all=TRUE))
gc()

## Load packages
lib = c("ggplot2","RColorBrewer","assignPOP","adegenet","stringr")
lapply(lib, library, character.only=TRUE)

## Import data
region.loc = read.Genepop("Genotype_data/lobster_region_baseline.gen",
                          pop.names=c("North_sea","Scandinavia","Atlantic"))
summary(region.loc)

## Perform Monte-Carlo cross-validation
?assign.MC
assign.MC(region.loc, 
          train.inds = c(0.5,0.7,0.9), # no. random ind from each pop
          train.loci = c(0.1,0.25,0.5,1), # top % high Fst loci (1=all loci)
          iterations = 100, # no. resampling times for each combination of training individuals and loci
          model = "svm", # predictive model used
          dir = "Region_svm") # directory

## Calculate assignment accuracies of MC cross-validation results
?accuracy.MC
accurMC = accuracy.MC(dir = "Region_svm/")

## Change label names
names(accurMC)
names(accurMC) = c("train.inds","train.loci","iters","assign.rate.all",
                   "assign.rate.Western North Sea",
                   "assign.rate.Scandinavia",
                   "assign.rate.Atlantic")

## Plot assignment accuracy results
region=accuracy.plot(accurMC, pop=c("Atlantic","Western North Sea",
                                    "Scandinavia"))+
  ylab("Proportion of lobsters correctly assigned")+
  xlab("Proportion of individuals used in training dataset")+
  scale_y_continuous(limits=c(0,1))+
  theme(
    # facet labels
    strip.text = element_text(colour="black", size=15) 
  )
region
# ggsave("Region_assignment_accuracy.pdf")
# ggsave("Region_assignment_accuracy.png")

## Print mean and SD across assignment tests
assign.matrix(dir="Region_svm/")
assign.matrix(dir="Region_svm/",
              train.inds = 0.7,
              train.loci=1)


# ----------------- #
#
# Regional Mediterranean assignment
#
# Central Med versus Aegean Sea
#
# ----------------- #

rm(list=ls(all=TRUE))
gc()

## Load packages
lib = c("ggplot2","RColorBrewer","assignPOP","adegenet","stringr")
lapply(lib, library, character.only=TRUE)

## Import data
region.loc = read.Genepop("Genotype_data/lobster_region_baseline_med.gen",
                          pop.names=c("Central_Med","Aegean_Sea"))
summary(region.loc)

## Perform Monte-Carlo cross-validation
?assign.MC
assign.MC(region.loc, 
          train.inds = c(0.5,0.7,0.9), # no. random ind from each pop
          train.loci = c(0.1,0.25,0.5,1), # top % high Fst loci (1=all loci)
          iterations = 100, # no. resampling times for each combination of training individuals and loci
          model = "svm", # predictive model used
          dir = "Region_svm_Med/") # directory

## Calculate assignment accuracies of MC cross-validation results
?accuracy.MC
accurMC = accuracy.MC(dir = "Region_svm_Med/")

## Change label names
names(accurMC)
names(accurMC) = c("train.inds","train.loci","iters","assign.rate.all",
                   "assign.rate.Central Mediterranean",
                   "assign.rate. Aegean Sea")

## Plot assignment accuracy results
region.med=accuracy.plot(accurMC, pop=c("Central Mediterranean"," Aegean Sea"))+
  ylab("Proportion of lobsters correctly assigned")+
  xlab("Proportion of individuals used in training dataset")+
  scale_y_continuous(limits=c(0,1))+
  theme(
    # facet labels
    strip.text = element_text(colour="black", size=15) 
  )
region.med
# ggsave("Region_assignment_accuracy_med.pdf")
# ggsave("Region_assignment_accuracy_med.png")

## Print mean and SD across assignment tests
assign.matrix(dir="Region_svm_Med/")
assign.matrix(dir="Region_svm_Med/",
              train.inds = 0.7,
              train.loci=1)


#### Combine ggplots
library(cowplot)
ggtheme = theme(
            # facet labels
            strip.text = element_text(colour="black", size=15),
            axis.title.x = element_blank(),
            axis.title.y = element_text(size=13),
            axis.text = element_text(size=11),
            legend.text = element_text(size=11),
            legend.title = element_text(size=13)
)
ggtheme2 = theme(
              axis.title.x = element_text(size=13),
              axis.title.y = element_text(size=13),
              axis.text = element_text(size=11),
              legend.text = element_text(size=11),
              legend.title = element_text(size=13)
)
plot_grid(basin + ggtheme,
          region + ggtheme,
          region.med + ggtheme2,
          nrow=3, labels = c("A","B","C"))
# ggsave(file="assignment_combined.png", width=10, height=12)
# ggsave(file="assignment_combined.pdf", width=10, height=12)
