#======================================
# SNP dataset quality control & summary statistics
#
# European lobster (Homarus gammarus)
# 
# Tom Jenkins | t.l.jenkins@exeter.ac.uk
#
# Jenkins et al. 2019 Evolutionary Applications
# 
#======================================

## Load packages
lib = c("ade4","adegenet","tidyr","seqinr","ggplot2","RColorBrewer","mmod",
        "pegas","vegan","ggrepel","poppr","reshape2")
lapply(lib, library, character.only=TRUE)


# ----------------- #
#
# Data import and preparation
#
# ----------------- #

## Import and convert raw data
rawdata = read.csv("Lobster_SNP_Raw_Genotypes.csv", header=TRUE)
rawdata = reshape(rawdata, idvar=c("Sample","Site"), timevar="Locus",
                  direction = "wide", sep="")

## Remove "Genotype" from column names
colnames(rawdata)
colnames(rawdata) = gsub("Genotype", "", colnames(rawdata)); colnames(rawdata)

## Subset genotype data
geno = rawdata[ , 3:98]

## Remove SNP assays that did not perform well on the Fluidigm EP1
snps_to_remove = c("25580","32362","41521","53889","65376")
geno = geno[ , !colnames(geno) %in% snps_to_remove]

## Create vector of individuals and of population IDs
ind = as.character(rawdata$Sample) # individual labels
population = as.character(rawdata$Site) # population labels

## Convert to Genind object
snpdata = df2genind(geno, ploidy=2, ind.names=ind, pop=population, sep="")
snpdata
snpdata$tab[1:2,1:10] # check first two individual's genotypes are correct


# ----------------- #
#
# Missing data check
#
# ----------------- #

## Loci missing data
locmiss = propTyped(snpdata, by="loc")
locmiss
locmiss[which(locmiss < 0.8)] # more than 20% missing data

## Indivual missing data
indmiss = propTyped(snpdata, by="ind")
indmiss
indmiss[which(indmiss < 0.8)] # more than 20% missing data

### Poppr VERY USEFUL FUNCTIONS ###

## Remove loci with missing data
snpdata = missingno(snpdata, type="loci", cutoff=0.2)
snpdata

## Remove samples with missing data
snpdata = missingno(snpdata, type="geno", cutoff=0.2)
snpdata


# ----------------- #
#
# Data exploration
#
# ----------------- #

## Dataset summary
snpdata
locNames(snpdata)

## Check for duplicate genotypes
?mlg
mlg(snpdata)
genoIDs = mlg.id(snpdata) ; genoIDs
for (i in genoIDs){ # for each element in the list genoIDs
  if (length(genoIDs[i]) > 1){ # if the length is greater than two
    print(i) # print individuals that are duplicates
  }
}
# duplicates potentially due to double-sampling / contamination

## Remove duplicated genotypes
dups = c("Laz4","Eye15","Eye01","Tar2","Gul101","Eye25","Iom02",
         "Hel07","Eye05","Eye06","Cro08","Laz1","Eye14","Tar3",
         "Lyn04","Lyn15","Eye07","Eye20","Eye02")
indnames = indNames(snpdata) # individuals names
nodups = indnames[! indnames %in% dups] # remove dups from vector
nodups
(snpdata2 = snpdata[nodups, ]) # new genind object without duplicates
mlg(snpdata2) # re-check for duplicates


## Dataset summary
snpdata2
locNames(snpdata2)
x = summary(snpdata2) ; x
x$n.by.pop # number of individuals in each pop

## Heterozygosity
x$Hobs
x$Hobs[which(x$Hobs > 0.5)] # loci > 0.5 obs het
x$Hexp
x$Hexp[which(x$Hexp > 0.5)] # loci > 0.5 exp het
plot(x$Hobs, xlab="Loci number", ylab="Observed Heterozygosity", 
     main="Observed heterozygosity per locus")
plot(x$Hobs, x$Hexp, xlab="Hobs", ylab="Hexp", 
     main="Expected heterozygosity as a function of observed heterozygosity per locus")
bartlett.test(list(x$Hexp, x$Hobs)) # a test : H0: Hexp = Hobs


# ----------------- #
#
# Hardy Weinberg Equilibrium
#
# ----------------- #

## Hardy Weinberg equilibrium test over entire dataset
# hwe_full = hw.test(snpdata2, B=1000)
# hwe_full

## Hardy Weinberg equilibrium test for each pop
# hwe_pop = seppop(snpdata2) %>% lapply(hw.test, B=1000)
# hwe_pop
# save(hwe_pop, file="lobster_hwe_test.RData")
load("lobster_hwe_test.RData")

## Extract population-wise p-values
hwe_pval = sapply(hwe_pop, "[", i=TRUE, j=4) # all rows in fourth column
hwe_pval

## Bonferroni correction for multiple comparisons
hwe_pval_bon = apply(hwe_pval, 2, p.adjust, method="bonferroni")
hwe_pval_bon
hwe_pval_bon[is.na(hwe_pval_bon)] = 0.01 # convert NAs to 0.01 (assume departure)
hwe_pval_bon[is.na(hwe_pval_bon)] # check there are no more NA values

## Number loci out of HWE in each pop (TRUE = departure from HWE)
summary(hwe_pval_bon < 0.05)

## Count number of pops out of HWE in each locus
loci_hwe = apply(hwe_pval_bon < 0.05, 1, sum)
loci_hwe

## Show loci that have >50 % pops out of HWE
loci_hwe[ which(loci_hwe > nPop(snpdata2)/2) ]
## remove loci 8953 and 21197


# ----------------- #
#
# Linkage disequilibrium
#
# ----------------- #

## LD test in the case of unphased genotypes
?LD2

## Separate by pop, convert to pegas loci object and remove NAs
ld.dataset = seppop(snpdata2) %>% lapply(genind2loci) %>% lapply(drop_na)
ld.dataset

## Create a list of pairs of loci
loci.pairs = combn(seq(1,nLoc(snpdata2)), 2, simplify = FALSE)
loci.pairs[[1]]

## LD tests on each pop for each pair of loci
LD2(ld.dataset[[1]], locus=loci.pairs[[1]], details=F) # 1st pop & 1st pair
lapply(ld.dataset, LD2, locus=loci.pairs[[1]], details=F) # 40 pops & 1st pair
# ld.result = lapply(loci.pairs, function(x) lapply(ld.dataset, LD2, locus=x, details=F)) # all pops all pairs
# save(ld.result, file="lobster_ld_test.RData")
load("lobster_ld_test.RData")

## Explore results
ld.result[[1]] # first loci pair all pops
ld.result[[1]][1] # first loci pair 1st pop
ld.result[[1]][40] # first loci pair 40th pop
ld.result[[4005]][5] # last loci pair 5th pop

## Create dataframe and convert to long format
ld.df = data.frame(loci.pairs)
library(data.table)
ld.df = transpose(ld.df) # transpose into long format
colnames(ld.df) = c("locus1","locus2") # change column names
head(ld.df)

## Convert numbers to locus names
ld.df$locus1 = as.factor(ld.df$locus1) # convert column to factor
ld.df$locus2 = as.factor(ld.df$locus2) # convert column to factor
levels(ld.df$locus1) = head(locNames(snpdata2), 89) # loci names 1-89
levels(ld.df$locus2) = tail(locNames(snpdata2), 89) # loci names 2-90
head(ld.df)

##  Extract and add pvalues for each pop to dataframe
names(ld.dataset)
ld.df$ale = sapply(lapply(ld.result, "[[", i=1), # extract first element (ale pop)
                   "[[", i=3) # extract third element (pvalue)
ld.df$ber = sapply(lapply(ld.result, "[[", i=2), "[[", i=3) 
ld.df$brd = sapply(lapply(ld.result, "[[", i=3), "[[", i=3) 
ld.df$cor = sapply(lapply(ld.result, "[[", i=4), "[[", i=3) 
ld.df$cro = sapply(lapply(ld.result, "[[", i=5), "[[", i=3) 
ld.df$eye = sapply(lapply(ld.result, "[[", i=6), "[[", i=3) 
ld.df$flo = sapply(lapply(ld.result, "[[", i=7), "[[", i=3) 
ld.df$gul = sapply(lapply(ld.result, "[[", i=8), "[[", i=3) 
ld.df$heb = sapply(lapply(ld.result, "[[", i=9), "[[", i=3) 
ld.df$hel = sapply(lapply(ld.result, "[[", i=10), "[[", i=3) 
ld.df$hoo = sapply(lapply(ld.result, "[[", i=11), "[[", i=3) 
ld.df$idr16 = sapply(lapply(ld.result, "[[", i=12), "[[", i=3) 
ld.df$idr17 = sapply(lapply(ld.result, "[[", i=13), "[[", i=3) 
ld.df$iom = sapply(lapply(ld.result, "[[", i=14), "[[", i=3) 
ld.df$ios = sapply(lapply(ld.result, "[[", i=15), "[[", i=3) 
ld.df$jer = sapply(lapply(ld.result, "[[", i=16), "[[", i=3) 
ld.df$kav = sapply(lapply(ld.result, "[[", i=17), "[[", i=3) 
ld.df$kil = sapply(lapply(ld.result, "[[", i=18), "[[", i=3) 
ld.df$laz = sapply(lapply(ld.result, "[[", i=19), "[[", i=3) 
ld.df$loo = sapply(lapply(ld.result, "[[", i=20), "[[", i=3)
ld.df$lyn = sapply(lapply(ld.result, "[[", i=21), "[[", i=3) 
ld.df$lys = sapply(lapply(ld.result, "[[", i=22), "[[", i=3) 
ld.df$mul = sapply(lapply(ld.result, "[[", i=23), "[[", i=3) 
ld.df$oos = sapply(lapply(ld.result, "[[", i=24), "[[", i=3) 
ld.df$ork = sapply(lapply(ld.result, "[[", i=25), "[[", i=3) 
ld.df$pad = sapply(lapply(ld.result, "[[", i=26), "[[", i=3) 
ld.df$pem = sapply(lapply(ld.result, "[[", i=27), "[[", i=3) 
ld.df$sar13 = sapply(lapply(ld.result, "[[", i=28), "[[", i=3) 
ld.df$sar17 = sapply(lapply(ld.result, "[[", i=29), "[[", i=3) 
ld.df$sbs = sapply(lapply(ld.result, "[[", i=30), "[[", i=3) 
ld.df$she = sapply(lapply(ld.result, "[[", i=31), "[[", i=3) 
ld.df$sin = sapply(lapply(ld.result, "[[", i=32), "[[", i=3) 
ld.df$sky = sapply(lapply(ld.result, "[[", i=33), "[[", i=3) 
ld.df$sul = sapply(lapply(ld.result, "[[", i=34), "[[", i=3) 
ld.df$tar = sapply(lapply(ld.result, "[[", i=35), "[[", i=3) 
ld.df$the = sapply(lapply(ld.result, "[[", i=36), "[[", i=3) 
ld.df$tor = sapply(lapply(ld.result, "[[", i=37), "[[", i=3) 
ld.df$tro = sapply(lapply(ld.result, "[[", i=38), "[[", i=3) 
ld.df$ven = sapply(lapply(ld.result, "[[", i=39), "[[", i=3) 
ld.df$vig = sapply(lapply(ld.result, "[[", i=40), "[[", i=3) 
rm(ld.result) # remove to save memory

## Pvalue Bonferroni correction
ld.df.bon = data.frame(apply(ld.df[3:42], MARGIN=2, FUN=p.adjust, 
                             method="bonferroni"))
ld.df.bon = cbind(ld.df[1:2], ld.df.bon) # merge loci and pvalue data

## Tranform data to long format
ld.bon.long = melt(ld.df.bon, id.vars = c("locus1","locus2"),
                   variable.name = "pop", value.name = "pval_bon")
head(ld.bon.long)

## Subset all bon p-values <0.05
ld.bon.long = subset(ld.bon.long, pval_bon<0.05)

## Order dataframe by locus1 then by locus2
ld.bon.long = ld.bon.long[order(ld.bon.long$locus1, ld.bon.long$locus2), ]

## Show loci that have many pops with a bon p-value <0.05
loci = c("15531","53935") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## remove 15531 due to more missing data
loci = c("28357","56785") # atl dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## remove 28357 due to more missing data

## H_gam_22740
loci = c("22740","33066") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("22740","51507") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("22740","53052") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("22740","53263") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("22740","65064") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("22740","65576") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## H_gam_33066
loci = c("33066","22740") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("33066","51507") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("33066","53052") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("33066","53263") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("33066","65064") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("33066","65576") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## H_gam_51507
loci = c("51507","22740") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("51507","33066") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("51507","53052") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("51507","53263") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("51507","65064") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("51507","65576") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## H_gam_53052
loci = c("53052","22740") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53052","33066") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53052","53263") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53052","65064") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53052","65576") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## H_gam_53263
loci = c("53263","22740") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53263","33066") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53263","53052") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53263","65064") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("53263","65576") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## H_gam_65064
loci = c("65064","22740") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("65064","33066") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("65064","51507") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("65064","53263") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
loci = c("65064","65576") # full dataset
ld.bon.long[ld.bon.long$locus1 %in% loci & ld.bon.long$locus2 %in% loci, ]
## remove 22740, 33066, 51507, 53052, 53263 due to frequency of LD


# ----------------- #
#
# Final dataset filtering
#
# ----------------- #

## Remove loci that depart from HWE or have unusual heterozygosity
snpdata2
locname = locNames(snpdata2) ; locname # locus names
loc2remove = c("8953","21197", # hwe
               "15531","22740","28357","33066","51507","53052","53263", # LD
               "21880","22323") # heterozygosity 
locname = locname[! locname %in% loc2remove] ;locname # filtered loci
data_filt = snpdata2[loc=locname] # new genind dataset with filtered loci

## Filtered dataset summary
data_filt
locNames(data_filt)
f = summary(data_filt) ; f
f$n.by.pop # number of individuals in each pop

## Heterozygosity
f$Hobs
f$Hobs[which(f$Hobs > 0.5)] # loci > 0.5 obs het
f$Hexp
f$Hexp[which(f$Hexp > 0.5)] # loci > 0.5 exp het
plot(f$Hobs, xlab="Loci number", ylab="Observed Heterozygosity", 
     main="Observed heterozygosity per locus")
plot(f$Hobs, f$Hexp, xlab="Hobs", ylab="Hexp", 
     main="Expected heterozygosity as a function of observed heterozygosity per locus")
bartlett.test(list(f$Hexp, f$Hobs)) # a test : H0: Hexp = Hobs

## Allele frequencies
af = apply(tab(data_filt, freq=TRUE), 2, mean, na.rm=TRUE)
af
# write.csv(af, file="allele_freqs.csv")

## Minor allele frequencies
minorAllele(data_filt)

## Are loci polymorphic?
isPoly(data_filt)

## Expected heterozygosity per pop
mean.hexp = Hs(data_filt) ; mean.hexp
barplot(unlist(mean.hexp), las=2)

## Observed heterozygosity per pop
n.pop = seppop(data_filt)
mean.hobs = do.call("c", lapply(n.pop, function(x) mean(summary(x)$Hobs))) 
mean.hobs
barplot(unlist(mean.hobs), las=2)

## Output Ho and Hs
# df = cbind(mean.hobs, mean.hexp)
# write.csv(df, file="Adegenet_obs_exp_het.csv", row.names=TRUE)

## Output filtered genind object
title = paste("lobster_",nInd(data_filt),"ind_",nLoc(data_filt),
              "snps_",nPop(data_filt),"pop.RData",sep="")
title
# save(data_filt, file=title)

