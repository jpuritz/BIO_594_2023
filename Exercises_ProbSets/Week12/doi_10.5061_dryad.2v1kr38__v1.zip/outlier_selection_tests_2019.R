#======================================
# RADseq dataset outlier selection tests analysis
#
# European lobster (Homarus gammarus)
# 
# Tom Jenkins | t.l.jenkins@exeter.ac.uk
#
# Jenkins et al. 2019 Evolutionary Applications
# 
#======================================

rm(list=ls(all=TRUE))

## Load packages
lib = c("ade4","RColorBrewer","adegenet","seqinr","poppr","ggplot2","mmod",
        "pegas","plyr","hierfstat","diveRsity","dartR")
lapply(lib, library, character.only=TRUE)


# ----------------- #
#
# OutFLANK
#
# ----------------- #

### Full dataset analysis using 7,022 SNPs

## Import data
full.dataset = import2genind("RADseq_7022_snps_3grp.gen")
full.dataset
indNames(full.dataset)

## Change group labels
popNames(full.dataset) = c("Atlantic","Skagerrak","Mediterranean")
full.dataset$pop

## Edit locus names (remove everything after "_")
locNames(full.dataset)
locNames(full.dataset) = gsub("_.*", "", locNames(full.dataset))
locNames(full.dataset)

## Run OutFLANK using dartR wrapper script
full.outflnk = gl.outflank(full.dataset, qthreshold = 0.05)

## Outliers
full.outflnk = full.outflnk$outflank$results
summary(full.outflnk)

## Remove duplicated rows for each SNP
toRemove = seq(1, nrow(full.outflnk), by=2)
full.outflnk = full.outflnk[-toRemove, ]
summary(full.outflnk)

## Plot He verus Fst
plot(full.outflnk$He, full.outflnk$FST, pch=20, col="black")

## Get indexes for outliers
out_index = which(full.outflnk$OutlierFlag==TRUE)
out_index
full.out.outflnk = locNames(full.dataset)[out_index]
full.out.outflnk
# write.csv(full.out.outflnk, file="outlier_SNPs_OutFLANK.csv")


### Atlantic dataset analysis using 4,377 SNPs

## Import data
atl.dataset = import2genind("RADseq_Atl_4377_snps_9grp.gen")
atl.dataset

## Group labels
popNames(atl.dataset)

## Edit locus names (remove everything after "_")
locNames(atl.dataset)
locNames(atl.dataset) = gsub("_.*", "", locNames(atl.dataset))
locNames(atl.dataset)

## Run OutFLANK using dartR wrapper script
atl.outflnk = gl.outflank(atl.dataset, qthreshold = 0.05)

## Outliers
atl.outflnk = atl.outflnk$outflank$results
summary(atl.outflnk)

## Remove duplicated rows for each SNP
toRemove = seq(1, nrow(atl.outflnk), by=2)
atl.outflnk = atl.outflnk[-toRemove, ]
summary(atl.outflnk)

## Plot He verus Fst
plot(atl.outflnk$He, atl.outflnk$FST, pch=20, col="black")

## Get indexes for outliers
atl_index = which(atl.outflnk$OutlierFlag==TRUE)
atl_index


# ----------------- #
#
# PCadapt
# 
# PCadapt tutorial
# https://cran.r-project.org/web/packages/pcadapt/vignettes/pcadapt.html
#
# ----------------- #

## Load PCadapt
library(pcadapt)
library(LEA)

### Full dataset analysis using 7,022 SNPs

## Convert structure file (no marker row) to geno and lfmm file
# struct2geno("rad_full.str", ploidy=2, FORMAT=2, 
#             extra.row = 0, extra.column = 2) # ind and pop labels

## Read file
pcinput = read.pcadapt("RADseq_7022_snps_3grp.lfmm", type="lfmm")

## Run pcadapt with 10 retained principal components
x = pcadapt(pcinput, K=10)

## Scree plot
plot(x, option="screeplot")
plot(x, option="scores") # pop=poplist

## Run again with optimum number of PCs
y = pcadapt(pcinput, K=3)
summary(y)

## Manhatten plot of the p-values for each SNP
plot(y, option="manhattan")

## Check distribution of p-values using a Q-Q plot
plot(y, option="qqplot", threshold=0.05)

## Histograms of the test statistic and p-values
hist(y$pvalues, xlab="p-values", breaks=50)
plot(y, option="stat.distribution")

## Generate and extract qvalues
library(qvalue)
qval = qvalue(y$pvalues)$qvalues ; qval

## Define false discovery rate.
alpha = 0.05

## Which loci are outliers?
out_index = which(qval < alpha)
out_index
full.out.pcadapt = locNames(full.dataset)[out_index]
full.out.pcadapt
# write.csv(outliers_pcadapt, file="outlier_SNPs_PCAdapt.csv")


### Atlantic dataset analysis using 4,377 SNPs

## Read file
pcinput = read.pcadapt("RADseq_Atl_4377_snps_9grp.lfmm", type="lfmm")

## Run pcadapt with 10 retained principal components
x = pcadapt(pcinput, K=10)

## Scree plot
plot(x, option="screeplot")
plot(x, option="scores") # pop=poplist

## Run again with optimum number of PCs
y = pcadapt(pcinput, K=1)
summary(y)

## Manhatten plot of the p-values for each SNP
plot(y, option="manhattan")

## Check distribution of p-values using a Q-Q plot
plot(y, option="qqplot", threshold=0.05)

## Histograms of the test statistic and p-values
hist(y$pvalues, xlab="p-values", breaks=50)
plot(y, option="stat.distribution")

## Generate and extract qvalues
library(qvalue)
qval = qvalue(y$pvalues)$qvalues ; qval

## Define false discovery rate.
alpha = 0.05

## Which loci are outliers?
out_index = which(qval < alpha)
out_index
atl.out.pcadapt = locNames(full.dataset)[out_index]
atl.out.pcadapt


# ----------------- #
#
# BayeScan (using prior_odds 10,000)
#
# ----------------- #

### Full dataset analysis using 7,022 SNPs

## Run Bayescan plot function
source("Bayescan/plot_bayescan_function.txt")
results = plot_bayescan("Bayescan/lobster_all_pops_fst.txt", FDR=0.05)
results$nb_outliers
results$outliers

## Which loci are outliers?
full.out.bay = locNames(full.dataset)[results$outliers]
full.out.bay


### Atlantic dataset analysis using 4,377 SNPs

## Run Bayescan plot function
source("Bayescan/plot_bayescan_function.txt")
results = plot_bayescan("Bayescan/atlantic_dataset_fst.txt", FDR=0.05)
results$nb_outliers
results$outliers

## Which loci are outliers?
atl.out.bay = locNames(full.dataset)[results$outliers]
atl.out.bay


# ----------------- #
#
# Common outliers among all tests
# 
# ----------------- #

full.out.outflnk
full.out.pcadapt
full.out.bay

## Print outliers identified from all selection tests
Reduce(intersect,list(full.out.outflnk,full.out.bay,full.out.pcadapt))



