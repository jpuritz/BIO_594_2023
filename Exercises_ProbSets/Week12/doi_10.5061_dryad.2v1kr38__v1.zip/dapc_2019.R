#======================================
# Analysis of population structure using dapc
#
# European lobster (Homarus gammarus)
# 
# Tom Jenkins | t.l.jenkins@exeter.ac.uk
#
# Jenkins et al. 2019 Evolutionary Applications
# 
#======================================


## Load packages
lib = c("adegenet","ggplot2","RColorBrewer","pegas","poppr","cowplot")
lapply(lib, library, character.only=TRUE)


# ----------------- #
#
# Data import and preparation
#
# ----------------- #

## Load RData SNP dataset
load("../lobster_1278ind_79snps_40pop.RData")
data_filt
nPop(data_filt)
summary(data_filt)$n.by.pop


# Section 1 ---------------------------------------------------------------


# ----------------- #
#
# DAPC using all SNPs
#
# ----------------- #

## Cross validation to find the optimal number of PCs to retain in dapc
x = tab(data_filt, NA.method="mean")
# xval = xvalDapc(x, data_filt$pop, n.pca.max=300, training.set=0.9,
#                 result="groupMean", center=TRUE, scale=FALSE,
#                 n.rep=30, n.pca=NULL, parallel="snow", ncpus=2)

## Number of PCs with best stats
xval$`Number of PCs Achieving Highest Mean Success`
xval$`Number of PCs Achieving Lowest MSE`
xval$`Root Mean Squared Error by Number of PCs of PCA` # lower score = better
# 70 PCs to retain

## Run the DAPC using population IDs as priors
dapc1 = dapc(data_filt, data_filt$pop, n.pca=70, n.da=3)

## Analyse how much percent of genetic variance is explained by each axis
percent = dapc1$eig/sum(dapc1$eig)*100
percent
barplot(percent, ylab="Percent of genetic variance explained by eigenvectors", 
        names.arg=round(percent, 2))

## SNP contributions
contrib = loadingplot(dapc1$var.contr)
contrib = loadingplot(dapc1$var.contr, threshold=0.005)
contrib$var.names

## Create data_filtframe with PC info
df_pca = as.data.frame(dapc1$ind.coord)

## Add a column containing individuals
df_pca = cbind(rownames(df_pca), df_pca)

## Rename first three columns
colnames(df_pca) = c("Indiv","PC1","PC2","PC3")

## Add a column with the population IDs
df_pca$pop = data_filt$pop

## Flip axis by multiplying by minus 1
df_pca[ , 2:4] = df_pca[ , 2:4]*-1

# ----------------- #
#
# Visualise DAPC using all 86 SNPs
#
# ----------------- #

## ggplot2 theme
ggtheme = theme(legend.title = element_blank(),
                axis.text.y = element_text(colour="black", size=14),
                axis.text.x = element_text(colour="black", size=14),
                axis.title = element_text(colour="black", size=14),
                legend.position = "top",
                legend.text = element_text(size=15),
                legend.key.size = unit(0.7,"cm"),
                legend.box.spacing = unit(0, "cm"),
                panel.border = element_rect(colour="black", fill=NA, size=1),
                plot.title = element_text(hjust=0.5, size=25) # title centered 
)


## Function to add country labels to population labels
addcountry = function(x){
  # If pop label is present function will output the country
  if(x=="Ale"|x=="The"|x=="Tor"|x=="Sky") y = " Aegean Sea "
  if(x=="Sar13"|x=="Sar17"|x=="Tar"|x=="Laz") y = " Central Mediterranean "
  if(x=="Jer") y = " Atlantic "
  if(x=="Idr16"|x=="Idr17") y = " Atlantic "
  if(x=="Hel") y = " Atlantic "
  if(x=="Cor"|x=="Hoo"|x=="Kil"|x=="Mul"|x=="Ven") y = " Atlantic "
  if(x=="Oos") y = " Oosterschelde "
  if(x=="Tro"|x=="Ber"|x=="Flo"|x=="Sin") y = " Atlantic "
  if(x=="Gul"|x=="Kav"|x=="Lys") y = " Atlantic "
  if(x=="Vig") y = " Atlantic "
  if(x=="Brd"|x=="Cro"|x=="Eye"|x=="Heb"|x=="Iom"|x=="Ios"|x=="Loo"|x=="Lyn"|x=="Ork"|x=="Pad"|x=="Pem"|x=="She"|x=="Sbs"|x=="Sul") y = " Atlantic "
  return(y)
}
df_pca$country = sapply(df_pca$pop, addcountry)  
unique(df_pca$country)

## Reorder levels for plotting
df_pca$country = factor(df_pca$country, 
                        levels=c(" Atlantic ",
                                 " Central Mediterranean ",
                                 " Aegean Sea ",
                                 " Oosterschelde "))

## Calculate centroid position for each population
centroid = aggregate(cbind(PC1, PC2, PC3) ~ pop, data=df_pca, FUN=mean)
centroid$country = sapply(centroid$pop, addcountry)

## Find and store coordinate info required to draw segments
segs = merge(df_pca, setNames(centroid, c("pop","oPC1S1","oPC2S2","oPC3S3")),
             by = "pop", sort = FALSE)

## Definitions
no_snps = nLoc(data_filt)
no_ind = nInd(data_filt)

## Colour Brewer definitions
# 60 is the highest number of qualitative colours
qual_col_pals = brewer.pal.info[brewer.pal.info$category == "qual",]
col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
col_vector
cols = c("#377EB8","#FDB462","#E31A1C","#FC8D59")

## Scatter plot axis 1 vs 2
all=ggplot(df_pca, aes(x=PC1, y=PC2))+ 
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spiders
  geom_segment(data=segs, mapping = aes(xend=oPC1S1, yend=oPC2S2,
                                          colour=country), show.legend=FALSE)+
  geom_point(aes(fill=country), shape=21, size=3, show.legend=TRUE)+
  # centroids
  geom_label(data=centroid, size=5, aes(label=pop, fill=country), show.legend=FALSE)+
  # geom_point(data_filt = centroid, size=5, colour=NA)+
  # geom_label_repel(data_filt=centroid, size=5, aes(label=pop), show.legend=FALSE)+
  scale_fill_manual(values=cols)+
  scale_color_manual(values=cols)+
  labs(x=paste("PC1 (",format(round(percent[1], 1), nsmall=1)," %)", sep=""))+
  labs(y=paste("PC2 (",format(round(percent[2], 1), nsmall=1)," %)", sep=""))+
  # ggtitle(paste("European lobster DAPC:", no_ind,"individuals |",
  #               no_snps, "SNPs"))+
  panel_border(colour="black", size=0.8)+
  ggtheme+
  # labs(tag="A")+
  # legend key on two lines
  guides(fill=guide_legend(nrow=1, byrow=TRUE))
all
## Export plot
title = paste("dapc_",no_ind,"ind_",no_snps,"snps_axis1vs2", sep="")
title
# ggsave(paste(title,".png",sep=""), width=10, height=8, dpi=900)
# ggsave(paste(title,".pdf",sep=""), width=10, height=8)


# Section 2 --------------------------------------------------------


# ----------------- #
#
# DAPC using outlier SNPs
#
# ----------------- #

## Create outlier Genind dataset
outliers = c("11291","15581","32358","42395","53935","58053",
             "65064","65576")
data.outlier = data_filt[loc=outliers]
data.outlier


## Cross validation to find the optimal number of PCs to retain in dapc
x = tab(data.outlier, NA.method="mean")
# xval = xvalDapc(x, data.outlier$pop, n.pca.max=300, training.set=0.9,
#                 result="groupMean", center=TRUE, scale=FALSE,
#                 n.rep=30, n.pca=NULL, parallel="snow", ncpus=2)

## Number of PCs with best stats
xval$`Number of PCs Achieving Highest Mean Success`
xval$`Number of PCs Achieving Lowest MSE`
xval$`Root Mean Squared Error by Number of PCs of PCA` # lower score = better
# 8 PCs to retain

## Run the DAPC using population IDs as priors
dapc1 = dapc(data.outlier, data.outlier$pop, n.pca=7, n.da=3)

## Analyse how much percent of genetic variance is explained by each axis
percent = dapc1$eig/sum(dapc1$eig)*100
percent
barplot(percent, ylab="Percent of genetic variance explained by eigenvectors", 
        names.arg=round(percent, 2))

## SNP contributions
contrib = loadingplot(dapc1$var.contr)
contrib = loadingplot(dapc1$var.contr, threshold=0.005)
contrib$var.names

## Create data_filtframe with PC info
df_pca = as.data.frame(dapc1$ind.coord)

## Add a column containing individuals
df_pca = cbind(rownames(df_pca), df_pca)

## Rename first three columns
colnames(df_pca) = c("Indiv","PC1","PC2","PC3")

## Add a column with the population IDs
df_pca$pop = data.outlier$pop

## Flip axis by multiplying by minus 1
# df_pca[ , 2:4] = df_pca[ , 2:4]

# ----------------- #
#
# Visualise DAPC using 21 SNPs 
#
# ----------------- #

## ggplot2 theme
ggtheme = theme(legend.title = element_blank(),
                axis.text.y = element_text(colour="black", size=14),
                axis.text.x = element_text(colour="black", size=14),
                axis.title = element_text(colour="black", size=14),
                # legend.justification = c(1,1),
                legend.position = "top",
                legend.text = element_text(size=15),
                legend.key.size = unit(0.7,"cm"),
                legend.box.spacing = unit(0, "cm"),
                panel.border = element_rect(colour="black", fill=NA, size=1),
                plot.title = element_text(hjust=0.5, size=25) # title centered 
)

## Function to add country labels to population labels
addcountry = function(x){
  # If pop label is present function will output the country
  if(x=="Ale"|x=="The"|x=="Tor"|x=="Sky") y = " Aegean Sea "
  if(x=="Sar13"|x=="Sar17"|x=="Tar"|x=="Laz") y = " Central Mediterranean "
  if(x=="Jer") y = " Atlantic "
  if(x=="Idr16"|x=="Idr17") y = " Atlantic "
  if(x=="Hel") y = " Atlantic "
  if(x=="Cor"|x=="Hoo"|x=="Kil"|x=="Mul"|x=="Ven") y = " Atlantic "
  if(x=="Oos") y = " Oosterschelde "
  if(x=="Tro"|x=="Ber"|x=="Flo"|x=="Sin") y = " Atlantic "
  if(x=="Gul"|x=="Kav"|x=="Lys") y = " Atlantic "
  if(x=="Vig") y = " Atlantic "
  if(x=="Brd"|x=="Cro"|x=="Eye"|x=="Heb"|x=="Iom"|x=="Ios"|x=="Loo"|x=="Lyn"|x=="Ork"|x=="Pad"|x=="Pem"|x=="She"|x=="Sbs"|x=="Sul") y = " Atlantic "
  return(y)
}
df_pca$country = sapply(df_pca$pop, addcountry)  
unique(df_pca$country)

## Reorder levels for plotting
df_pca$country = factor(df_pca$country, 
                        levels=c(" Atlantic ",
                                 " Central Mediterranean ",
                                 " Aegean Sea ",
                                 " Oosterschelde "))


## Calculate centroid position for each population
centroid = aggregate(cbind(PC1, PC2, PC3) ~ pop, data=df_pca, FUN=mean)
centroid$country = sapply(centroid$pop, addcountry)

## Find and store coordinate info required to draw segments
segs = merge(df_pca, setNames(centroid, c("pop","oPC1S1","oPC2S2","oPC3S3")),
             by = "pop", sort = FALSE)

## Definitions
no_snps = nLoc(data.outlier)
no_ind = nInd(data.outlier)

# Colours
# cols = c("#377EB8","#FDB462","#E31A1C")
cols = c("#377EB8","#FDB462","#E31A1C","#FC8D59")

## Scatter plot axis 1 vs 2
out=ggplot(df_pca, aes(x=PC1, y=PC2))+ 
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spiders
  geom_segment(data=segs, mapping = aes(xend=oPC1S1, yend=oPC2S2,
                                        colour=country), show.legend=FALSE)+
  geom_point(aes(fill=country), shape=21, size=3, show.legend=TRUE)+
  # centroids
  geom_label(data=centroid, size=5, aes(label=pop, fill=country), show.legend=FALSE)+
  scale_x_continuous(breaks=c(0,5))+
  scale_fill_manual(values=cols)+
  scale_color_manual(values=cols)+
  labs(x=paste("PC1 (",round(percent[1],digits=1)," %)", sep=""))+
  labs(y=paste("PC2 (",round(percent[2],digits=1)," %)", sep=""))+
  # ggtitle(paste("European lobster DAPC:", no_ind,"individuals |",
  #               no_snps, "SNPs"))+
  panel_border(colour="black", size=0.8)+
  ggtheme+
  # labs(tag="B")+
  # legend key on two lines
  guides(fill=guide_legend(nrow=1, byrow=TRUE))
out
## Export plot
title = paste("dapc_",no_ind,"ind_",no_snps,"snps_axis1vs2", sep="")
title
# ggsave(paste(title,".png",sep=""), width=10, height=8, dpi=900)
# ggsave(paste(title,".pdf",sep=""), width=10, height=8)


# Section 3 ---------------------------------------------------------------


# ----------------- #
#
# DAPC using neutral SNPs
#
# ----------------- #

## Create neutral Genind dataset
neutral = setdiff(locNames(data_filt), outliers)
data.neutral = data_filt[loc=neutral]
data.neutral

## Cross validation to find the optimal number of PCs to retain in dapc
x = tab(data.neutral, NA.method="mean")
# xval = xvalDapc(x, data.neutral$pop, n.pca.max=300, training.set=0.9,
#                 result="groupMean", center=TRUE, scale=FALSE,
#                 n.rep=30, n.pca=NULL, parallel="snow", ncpus=2)

## Number of PCs with best stats
xval$`Number of PCs Achieving Highest Mean Success`
xval$`Number of PCs Achieving Lowest MSE`
xval$`Root Mean Squared Error by Number of PCs of PCA` # lower score = better
# 35 PCs to retain

## Run the DAPC using population IDs as priors
dapc1 = dapc(data.neutral, data.neutral$pop, n.pca=35, n.da=3)

## Analyse how much percent of genetic variance is explained by each axis
percent = dapc1$eig/sum(dapc1$eig)*100
percent
barplot(percent, ylab="Percent of genetic variance explained by eigenvectors", 
        names.arg=round(percent, 2))

## SNP contributions
contrib = loadingplot(dapc1$var.contr)
contrib = loadingplot(dapc1$var.contr, threshold=0.005)
contrib$var.names

## Create data_filtframe with PC info
df_pca = as.data.frame(dapc1$ind.coord)

## Add a column containing individuals
df_pca = cbind(rownames(df_pca), df_pca)

## Rename first three columns
colnames(df_pca) = c("Indiv","PC1","PC2","PC3")

## Add a column with the population IDs
df_pca$pop = data.neutral$pop

## Flip axis by multiplying by minus 1
df_pca[ , 2:4] = df_pca[ , 2:4]*-1

# ----------------- #
#
# Visualise DAPC
#
# ----------------- #

## ggplot2 theme
ggtheme = theme(legend.title = element_blank(),
                axis.text.y = element_text(colour="black", size=14),
                axis.text.x = element_text(colour="black", size=14),
                axis.title = element_text(colour="black", size=14),
                # legend.justification = c(1,1),
                legend.position = "top",
                legend.text = element_text(size=15),
                legend.key.size = unit(0.7,"cm"),
                legend.box.spacing = unit(0, "cm"),
                panel.border = element_rect(colour="black", fill=NA, size=1),
                plot.title = element_text(hjust=0.5, size=25) # title centered 
)

## Function to add country labels to population labels
addcountry = function(x){
  # If pop label is present function will output the country
  if(x=="Ale"|x=="The"|x=="Tor"|x=="Sky") y = " Aegean Sea "
  if(x=="Sar13"|x=="Sar17"|x=="Tar"|x=="Laz") y = " Central Mediterranean "
  if(x=="Jer") y = " Atlantic "
  if(x=="Idr16"|x=="Idr17") y = " Atlantic "
  if(x=="Hel") y = " Atlantic "
  if(x=="Cor"|x=="Hoo"|x=="Kil"|x=="Mul"|x=="Ven") y = " Atlantic "
  if(x=="Oos") y = " Oosterschelde "
  if(x=="Tro"|x=="Ber"|x=="Flo"|x=="Sin") y = " Atlantic "
  if(x=="Gul"|x=="Kav"|x=="Lys") y = " Atlantic "
  if(x=="Vig") y = " Atlantic "
  if(x=="Brd"|x=="Cro"|x=="Eye"|x=="Heb"|x=="Iom"|x=="Ios"|x=="Loo"|x=="Lyn"|x=="Ork"|x=="Pad"|x=="Pem"|x=="She"|x=="Sbs"|x=="Sul") y = " Atlantic "
  return(y)
}
df_pca$country = sapply(df_pca$pop, addcountry)  
unique(df_pca$country)

## Reorder levels for plotting
df_pca$country = factor(df_pca$country, 
                        levels=c(" Atlantic ",
                                 " Central Mediterranean ",
                                 " Aegean Sea ",
                                 " Oosterschelde "))

## Calculate centroid position for each population
centroid = aggregate(cbind(PC1, PC2, PC3) ~ pop, data=df_pca, FUN=mean)
centroid$country = sapply(centroid$pop, addcountry)

## Find and store coordinate info required to draw segments
segs = merge(df_pca, setNames(centroid, c("pop","oPC1S1","oPC2S2","oPC3S3")),
             by = "pop", sort = FALSE)

## Definitions
no_snps = nLoc(data.neutral)
no_ind = nInd(data.neutral)

## Colour definitions
# cols = c("#377EB8","#FDB462","#E31A1C")
cols = c("#377EB8","#FDB462","#E31A1C","#FC8D59")

## Scatter plot axis 1 vs 2
neu=ggplot(df_pca, aes(x=PC1, y=PC2))+ 
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spiders
  geom_segment(data=segs, mapping = aes(xend=oPC1S1, yend=oPC2S2,
                                        colour=country), show.legend=FALSE)+
  geom_point(aes(fill=country), shape=21, size=3, show.legend=TRUE)+
  # centroids
  geom_label(data=centroid, size=5, aes(label=pop, fill=country), show.legend=FALSE)+
  # geom_point(data_filt = centroid, size=5, colour=NA)+
  # geom_label_repel(data_filt=centroid, size=5, aes(label=pop), show.legend=FALSE)+
  scale_fill_manual(values=cols)+
  scale_color_manual(values=cols)+
  labs(x=paste("PC1 (",round(percent[1],digits=1)," %)", sep=""))+
  labs(y=paste("PC2 (",round(percent[2],digits=1)," %)", sep=""))+
  # ggtitle(paste("European lobster DAPC:", no_ind,"individuals |",
  #               no_snps, "SNPs"))+
  panel_border(colour="black", size=0.8)+
  ggtheme+
  # labs(tag="C")+
  # legend key on two lines
  guides(fill=guide_legend(nrow=1, byrow=TRUE))
neu
## Export plot
title = paste("dapc_",no_ind,"ind_",no_snps,"snps_axis1vs2", sep="")
title
# ggsave(paste(title,".png",sep=""), width=10, height=8, dpi=900)
# ggsave(paste(title,".pdf",sep=""), width=10, height=8)

## Scatter plot axis 1 vs 3
oos=ggplot(df_pca, aes(x=PC1, y=PC3))+ 
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spiders
  geom_segment(data=segs, mapping = aes(xend=oPC1S1, yend=oPC3S3,
                                        colour=country), show.legend=FALSE)+
  geom_point(aes(fill=country), shape=21, size=3, show.legend=TRUE)+
  # centroids
  geom_label(data=centroid, size=5, aes(label=pop, fill=country), show.legend=FALSE)+
  # geom_point(data_filt = centroid, size=5, colour=NA)+
  # geom_label_repel(data_filt=centroid, size=5, aes(label=pop), show.legend=FALSE)+
  scale_fill_manual(values=cols)+
  scale_color_manual(values=cols)+
  labs(x=paste("PC1 (",format(round(percent[1], 1), nsmall=1)," %)", sep=""))+
  labs(y=paste("PC3 (",format(round(percent[3], 1), nsmall=1)," %)", sep=""))+
  # ggtitle(paste("European lobster DAPC:", no_ind,"individuals |",
  #               no_snps, "SNPs"))+
  panel_border(colour="black", size=0.8)+
  ggtheme+
  # labs(tag="C")+
  # legend key on two lines
  guides(fill=guide_legend(nrow=1, byrow=TRUE))
oos
## Export plot
title = paste("dapc_",no_ind,"ind_",no_snps,"snps_axis1vs3", sep="")
title
# ggsave(paste(title,".png",sep=""), width=10, height=8, dpi=900)
# ggsave(paste(title,".pdf",sep=""), width=10, height=8)



# ----------------- #
#
# Combine plots the using cowplot package
#
# ----------------- #

library(cowplot)

## Extract legend from one of the ggplots
mylegend = get_legend(oos + theme(legend.direction = "horizontal",
                                  legend.justification="center",
                                  legend.text = element_text(size=15),
                                  legend.key.size = unit(0.7,"cm"),
                                  legend.box.spacing = unit(0, "cm")))

## Add theme to plots
ggtheme = theme(legend.title = element_blank(),
                axis.text.y = element_text(colour="black", size=14),
                axis.text.x = element_text(colour="black", size=14),
                axis.title = element_text(colour="black", size=14),
                legend.position = "none"
)

## Combine plots
com = plot_grid(all + ggtheme,
                out + ggtheme,
                neu + ggtheme,
                oos + ggtheme,
                align = "vh",
                labels = c("A","B","C","D"),
                ncol = 2, nrow=2)
com

## Add legend to composite plot
# plot_grid(com, mylegend, nrow=2, rel_heights = c(1, 0.05))
plot_grid(mylegend, com, nrow=2, rel_heights = c(0.05, 1))

## Export plot
# ggsave(file="dapc_combined.png", width=12, height=10, dpi=600)
# ggsave(file="dapc_combined.pdf", width=12, height=10)


