myCall <- quote(mad(xx[,j], constant = curConst, na.rm = TRUE))
myCall[[1]]
myCall[[2]]
names(myCall)
