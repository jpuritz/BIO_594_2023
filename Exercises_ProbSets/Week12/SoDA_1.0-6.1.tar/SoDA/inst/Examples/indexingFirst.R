x <- seq(from=1.1, to=1.7, by=.1)
x
length(x)
x[c(1,3,1,5,1,7)]
